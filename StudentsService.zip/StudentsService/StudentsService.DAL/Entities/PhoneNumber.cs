﻿namespace StudentsService.DAL.Entities;

public class PhoneNumber
{
    public int Id { get; init; }
    public string Value { get; set; }
}
